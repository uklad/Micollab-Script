#!/bin/bash
#
# READ the following comments completely before changing
# this file. And you will need to change it with each patch.
#
# Control variables:
# SET THESE VARIABLES FOR EACH PATCH.
#
# Set patch_layer_1 to "ipnpm"
# Set patch_file_list_1 to include all modules patched for that layer.
#  Separate the modules with one blank space. Set it to "" if nothing
#  is patched for this layer.
#
# Set patch_layer_2 to "npm"
# Set patch_file_list_2 to include all modules patched for that layer.
#  Separate the modules with one blank space. Set it to "" if nothing
#  is patched for this layer.
#
# Set patch_layer_3 to "lib"
# Set patch_file_list_3 to include all modules patched for that layer.
#  Separate the modules with one blank space. Set it to "" if nothing
#  is patched for this layer.
#
# Set patch_layer_4 to "web"
# Set patch_file_list_4 to include all modules patched for that layer.
#  Separate the modules with one blank space. Set it to "" if nothing
#  is patched for this layer.
#
# Set patch_notes to a meaningful notes. Multi-line notes can
# be formed by using the \n character to separate the lines.
#
# Post patch customization:
#   If there are cusomtization jobs to do after the system has
#   been patched or unpatched, modify the two functions
#     post_patch_util()
#     post_unpatch_util()
#   to do what you want. Otherwise, just leave the two functions blank.
# 
patch_layer_1="ipnpm"
patch_file_list_1=""
patch_layer_2="npm"
patch_file_list_2="startnpm"
patch_layer_3="lib"
patch_file_list_3=""
patch_layer_4="web"
patch_file_list_4=""
patch_notes="NPM-4630 - Server Console escape to bash as root."
#
# Update this function with each patch to do any kind of customization
# before the system is patched.
#   
pre_patch_util()
{
:
}
#
# Update this function with each patch to do any kind of customization
# after the system has been patched.
#   
post_patch_util()
{
:
}

#
# Update this function with each patch to do any kind of customization
# after the system has been unpatched.
#   
post_unpatch_util()
{
:
}
#----------------------------------------------

# Constants:
rev_file="/usr/vm/config/Revision"
patch_src="."
#----------------------------------------------

# Patcher BEGIN

#----------------------------------------------
patch_util()
{
    # Arguments:
    #  $1 patch directory
    #  $2 file list

    # echo -e "patch_util: Got list $2"
    for i in $2
    do
      # Write to the Revision file.
      echo -e -n "$i " >> $rev_file
      echo -e -n "  Patching $i..."
      if [ -f "$1"/$i"_load" ]
      then
	echo -e -n "already patched...will keep original backup..."
      else
	mv $1/$i $1/$i"_load"
	echo -e -n "backing up original..."
      fi
      cp -f $patch_src/$i $1/$i
      chmod +x $1/$i
      echo -e "done."
    done
}

patch()
{
    # Prep work.
    echo -e "Preparing system..."
    pre_patch_util

    # Start replacing files.
    echo -e "Start replacing files..."
    
    # Record this in the Revision file.
    date >> $rev_file
    echo -e "Patch notes: $patch_notes" >> $rev_file
    echo -e -n "Patched modules: " >> $rev_file
    
    # IPNPM layer first:
    patch_util "/ipnpm" "$patch_file_list_1"
    
    # NPM layer second:
    patch_util "/usr/vm/bin" "$patch_file_list_2"
    
    # LIB layer third:
    patch_util "/usr/lib" "$patch_file_list_3"
    
    # WEB layer third:
    patch_util "/usr/share/tomcat/webapps" "$patch_file_list_4"
    #rm -f -r /usr/local/jakarta-tomcat/webapps/npm-admin
	rm -rf /usr/share/tomcat/webapps/npm-admin;
	unzip -o -q /usr/share/tomcat/webapps/npm-admin.war -d /usr/share/tomcat/webapps/npm-admin;

    # Post processing
    echo -e "  Updating patched system..."
    post_patch_util

    echo -e "\n" >> $rev_file
    echo -e "...Done!"
}

unpatch_util()
{
    # Arguments:
    #  $1 patch directory
    #  $2 file list

    for i in $2
    do
      # Write to the Revision file.
      echo -e -n "$i " >> $rev_file
      echo -e -n "  Restoring module $i..."
      if [ -f "$1"/$i"_load" ]
      then
	mv -f $1/$i"_load" $1/$i
	echo -e -n "restored and removed original backup..."
      else
	echo -e -n "did not find backup..."
      fi
      chmod +x $1/$i
      echo -e "done."
    done
}

unpatch()
{
    # Start restoring the old files.
    echo -e "Start restoring modules..."
    
    # Record this in the Revision file.
    date >> $rev_file
    echo -e "Patch notes: REVERSED $patch_notes" >> $rev_file
    echo -e -n "Restored modules: " >> $rev_file
    
    # IPNPM layer first:
    unpatch_util "/ipnpm" "$patch_file_list_1"
    
    # NPM layer second:
    unpatch_util "/usr/vm/bin" "$patch_file_list_2"
    
    # LIB layer third:
    unpatch_util "/usr/lib" "$patch_file_list_3"
    
    # WEB layer fourth:
    unpatch_util "/usr/share/tomcat/webapps" "$patch_file_list_4"
    rm -rf /usr/share/tomcat/webapps/npm-admin;
	unzip -o -q /usr/share/tomcat/webapps/npm-admin.war -d /usr/share/tomcat/webapps/npm-admin;
    
    # Post processing
    echo -e "  Updating restored system..."
    post_unpatch_util

    echo -e "\n" >> $rev_file
    echo -e "...Done!"
}

# MAIN: This is the main body of the script.
#
#
r_flag=0
v_flag=0
while getopts "rv" options; do
  case $options in
    r ) r_flag=1;;
    v ) v_flag=1;;
    \? ) echo "Usage: $0 [-r]"
         exit 1;;
  esac
done

# Shutdown the appropriate layer before patching
rebootnpm

if [ "$r_flag" -eq 1 ]
then
   unpatch
else
  patch
fi

# Now start up the appropriate layer
startnpm
service tomcat restart

#Patcher END
