from django.http import HttpResponse, HttpResponseRedirect, HttpResponseServerError, HttpResponseNotFound
from django.shortcuts import render_to_response
from django.shortcuts import render
from django.template import RequestContext
from django.conf import settings
from django.core import serializers
import os,time, re



baseurl_ucdiag = settings.BASEURL
log = settings.LOGGER
UPTIME_THRESHOLD = 5

def showtdcinfo(request):
    """This method handles the display of the TDC tab"""
    log.info("In ucdiag/tdc:showtdcinfo")
    tdc_info = ""

    curr_time = time.localtime()
    day = curr_time.tm_mday
    month= curr_time.tm_mon
    year = curr_time.tm_year
    hour = curr_time.tm_hour
    min = curr_time.tm_min
    sec = curr_time.tm_sec 
    date = '%4d-%02d-%02d 00:00:00' % (year, month, day)
    pattern = '%Y-%m-%d %H:%M:%S'
    epoch = int(time.mktime(time.strptime(date, pattern))) 
    
    ## Print the framework table to show the rest of the stuff..
    tdc_info+= "<a href=\"javascript:showTDCInformation('ACCTPRES','tdc_data','"+str(epoch)+"')\">ACCTPRES</a>&nbsp;|"
    ## Did to fix UCA-10328 tdc_info+= "&nbsp;<a href=\"javascript:showGenericTDCInformation('CALL_SERVICES','tdc_data','"+str(epoch)+"')\">CALL&nbsp;SERVICES</a>&nbsp;|"
    tdc_info+= "&nbsp;<a href=\"javascript:showTDCInformation('IMEVENTS','tdc_data','"+str(epoch)+"')\">IM&nbsp;EVENTS</a>&nbsp;|"
    tdc_info+= "&nbsp;<a href=\"javascript:showTDCInformation('PRES','tdc_data','"+str(epoch)+"')\">PRES</a>&nbsp;|"
    tdc_info+= "&nbsp;<a href=\"javascript:showTDCInformation('SIP_PROXY','tdc_data','"+str(epoch)+"')\">SIP&nbsp;PROXY</a>&nbsp;|"
    tdc_info+= "&nbsp;<a href=\"javascript:showTDCInformation('SIPREG','tdc_data','"+str(epoch)+"')\">SIP&nbsp;REG</a>&nbsp;|"
    tdc_info+= "&nbsp;<a href=\"javascript:showGenericTDCInformation('VISUAL_VOICEMAIL','tdc_data',"+str(epoch)+")\">VISUAL&nbsp;VOICEMAIL</a>&nbsp;"
    tdc_info+= "<br><br><div id=\"tdc_data\"> Loading ...</div><script>javascript:showTDCInformation('ACCTPRES','tdc_data','"+str(epoch)+"')</script>"

    return render(request, 'ucdiag/tdc/tdc.html', {'baseurl': baseurl_ucdiag, 
											   'action':'', 
											   'tab':'tdc',
											   'tdc_info':tdc_info, 
                                               'bctrail':'TDC'})
  
def convertEpochToISO8601(epoch_time):
    curr_time = time.localtime(float(epoch_time))
    day = curr_time.tm_mday
    month= curr_time.tm_mon
    year = curr_time.tm_year
    hour = curr_time.tm_hour
    min = curr_time.tm_min
    sec = curr_time.tm_sec
    date = '%4d-%02d-%02d' % (year, month, day)
    return date

def showVisualVMInfo(request):
    """ This method shows Visual VM related information from TDC"""
    log.info("In ucdiag/tdc:showVisualVMInfo")
    ## Get all the dates..
    command = "/bin/grep -h -e 'VISUAL_VOICEMAIL,[0-9]\+,2,' /opt/intertel/data/tdc.data.* | sort | cut -d\",\" -f2"
    search_day = request.GET['search_day']
    dates_array=[]
    p = os.popen(command)
    dates = p.readlines()
    rc = p.close()
    dates.reverse()
    for date in dates:
        is_selected = ''
        if date.startswith(search_day):
            is_selected = 'SELECTED'
        dates_array.append({'date_ISO': convertEpochToISO8601(date), 'date_epoch':date, 'is_selected': is_selected} )
    search_day_next_day = int(search_day) + 86400
    ## Now the rest of data
    command = " /bin/grep -h -e 'VISUAL_VOICEMAIL,[0-9]\+,1,' /opt/intertel/data/tdc.data.* | sort"
    #log.info(command)
    search_day = request.GET['search_day']
    search_day_next_day = int(search_day) + 86400
    visual_vm_info = []
    p = os.popen(command)
    visual_vm_lines = p.readlines()
    rc = p.close()
    if rc == None:
        for line in visual_vm_lines:
            # Time calculations
            line_variables = line.strip().split(',')
            epoch_time = line_variables[1]
            if (int(epoch_time) < int(search_day)) or (int(epoch_time) > search_day_next_day):
                continue
	    curr_time = time.localtime(float(line_variables[1]))
            day = curr_time.tm_mday
            month= curr_time.tm_mon
            year = curr_time.tm_year
            hour = curr_time.tm_hour
            min = curr_time.tm_min
            sec = curr_time.tm_sec
            display_time = "%s/%s/%s:%02d:%02d:%02d" % (str(month) , str(day) , str(year) , int(hour) , int(min) , int(sec))
	    VMSessionSucc = line_variables[3] 
            VMSessFail = line_variables[4]
            MakeCall = line_variables[5]
            FwdMsg = line_variables[6]
            DeleteMsg = line_variables[7]
            SetVMPin = line_variables[8]
            SendFax = line_variables[9]
            ## Now insert the info into the dictionary
            visual_vm_info.append( {'display_time':display_time , 'VMSessionSucc': VMSessionSucc , 'VMSessFail':VMSessFail , 'MakeCall':MakeCall , 'FwdMsg':FwdMsg, 'DeleteMsg':DeleteMsg , 'SetVMPin':SetVMPin , 'SendFax':SendFax} )
            #modules_info.append( {'module_name': module_name, 'uptime': uptime, 'restarts': restarts, 'status': status, 'curr_debug_level':curr_debug_level, 'status_operations':status_operations } )


    return render(request, 'ucdiag/ajax/modvisualVM.html', {'baseurl': baseurl_ucdiag,
                                                                        'action':'',
                                                                        'bctrail': 'Modules',
                                                                        'visual_vm_info': visual_vm_info,
									'dates_array' : dates_array
                                                                        })

def showCallServicesInfo(request):
    """ This method shows Call Services related information from TDC"""
    log.info("In ucdiag/tdc:showCallServicesInfo")
    command = "/bin/grep -h -e 'CALL_SERVICES,[0-9]\+,2,' /opt/intertel/data/tdc.data.* | sort | cut -d\",\" -f2"
    search_day = request.GET['search_day']
    dates_array=[]
    p = os.popen(command)
    dates = p.readlines()
    rc = p.close()
    dates.reverse()
    for date in dates:
        is_selected = '' 
        if date.startswith(search_day):
            is_selected = 'SELECTED' 
        dates_array.append({'date_ISO': convertEpochToISO8601(date), 'date_epoch':date, 'is_selected': is_selected} ) 
    search_day_next_day = int(search_day) + 86400
    command = " /bin/grep -h -e 'CALL_SERVICES,[0-9]\+,1,' /opt/intertel/data/tdc.data.* | sort"
    #log.info(command)
    call_services_info = []
    p = os.popen(command)
    call_services_lines = p.readlines()
    rc = p.close()
    if rc == None:
        for line in call_services_lines:
            # Time calculations
            line_variables = line.strip().split(',')
            epoch_time = line_variables[1]
            if (int(epoch_time) < int(search_day)) or (int(epoch_time) > search_day_next_day):
                continue
            curr_time = time.localtime(float(line_variables[1]))
            day = curr_time.tm_mday
            month= curr_time.tm_mon
            year = curr_time.tm_year
            hour = curr_time.tm_hour
            min = curr_time.tm_min
            sec = curr_time.tm_sec
            display_time = "%s/%s/%s:%02d:%02d:%02d" % (str(month) , str(day) , str(year) , int(hour) , int(min) , int(sec))
            PlaceCall = line_variables[3]
            Answer = line_variables[4]
            Hangup = line_variables[5]
            Hold = line_variables[6]
            Retrieve = line_variables[7]
            Deflect = line_variables[8]
            Transfer  = line_variables[9]
            Conference = line_variables[10]
            ## Now insert the info into the dictionary
            call_services_info.append( {'display_time':display_time , 'PlaceCall':PlaceCall , 'Answer':Answer , 'Hangup':Hangup , 'Hold':Hold , 'Retrieve':Retrieve , 'Deflect':Deflect , 'Transfer':Transfer , 'Conference':Conference } )


    return render(request, 'ucdiag/ajax/modCallServices.html', {'baseurl': baseurl_ucdiag,
                                                                        'action':'',
                                                                        'bctrail': 'Modules',
                                                                        'call_services_info': call_services_info,
									'dates_array': dates_array
                                                                        })
            
    


## Function to print information about module and if its running
def showSIPInfo(request):
    """ This method shows SIP information from TDC"""
    modulename= request.GET['modulename']
    log.info("In ucdiag/tdc:showSIPInfo:modulename="+modulename)
    allowed_modules = ["ACCTPRES","IMEVENTS","PRES","SIP_PROXY","SIPREG"]
    if modulename.lower() in (string.lower() for string in allowed_modules):
        log.info("proceeding because modulename matches")
    else:
        log.info("Quitting")
        return HttpResponseNotFound("SIP module id not found")
    command = "/bin/grep -h -e 'CALL_SERVICES,[0-9]\+,2,' /opt/intertel/data/tdc.data.* | sort | cut -d\",\" -f2"
    search_day = request.GET['search_day']
    p = os.popen(command)
    dates = p.readlines()
    rc = p.close()
    dates.reverse()
    search_day_next_day = int(search_day) + 86400

    ## Now check to see if the module is running
    line_variables = []
    command = "/bin/grep -h -e 'SIP_STATISTICS,[0-9]\+,1,"+modulename+"' /opt/intertel/data/tdc.data.* | sort "
    p = os.popen(command)
    sip_lines = p.readlines()
    rc = p.close()
    return_string = modulename+" statistics for "
    return_string += "<select name=\"visual_voicemail_drop_down\" id=\"visual_voicemail_drop_down\" onchange=\"javascript:showTDCInformation('"+modulename+"','tdc_data',this.options[this.selectedIndex].value)\">"
    for date in  dates:
        if date.startswith(search_day):
            return_string += "<option value=\""+date+"\" selected=\"selected\">"+convertEpochToISO8601(date)+"</option>"
        else:
            return_string += "<option value=\""+date+"\">"+convertEpochToISO8601(date)+"</option>"
    return_string += "</select>"


    return_string +="<table class=\"sme-border\"><tbody><tr><th class=\"sme-border\" rowspan=2>Time</th><th class=\"sme-border\" colspan=i3>Incoming Requests</th><th class=\"sme-border\" colspan=7>Incoming Response</th><th class=\"sme-border\" colspan=3>Outgoing Requests</th><th class=\"sme-border\" colspan=7>Outgoing Responses</th><th class=\"sme-border\" colspan=4>Errors</th>"
    ## Incoming requests
    ##return_string += "<tr><th class=\"sme-border\">I<br>n<br>v<br>i<br>t<br>e</th>"
    ##return_string += "<th class=\"sme-border\">A<br>c<br>k</th>"
    ##return_string += "<th class=\"sme-border\">O<br>p<br>t<br>i<br>o<br>n<br>s</th>"
    ##return_string += "<th class=\"sme-border\">B<br>y<br>e</th>"
    ##return_string += "<th class=\"sme-border\">C<br>a<br>n<br>c<br>e<br>l</th>"
    return_string += "<tr><th class=\"sme-border\">Register</th>"
    ##return_string += "<th class=\"sme-border\">I<br>n<br>f<br>o</th>"
    ##return_string += "<th class=\"sme-border\">P<br>r<br>a<br>c<br>k</th>"
    ##return_string += "<th class=\"sme-border\">R<br>e<br>f<br>e<br>r</th>"
    return_string += "<th class=\"sme-border\">Subscribe</th>"
    return_string += "<th class=\"sme-border\">Notify</th>"
    ##return_string += "<th class=\"sme-border\">U<br>p<br>d<br>a<br>t<br>e</th>"
    ##return_string += "<th class=\"sme-border\">M<br>e<br>s<br>s<br>a<br>g<br>e</th>"
    ##return_string += "<th class=\"sme-border\">C<br>o<br>m<br>e<br>t</th>"
    ##return_string += "<th class=\"sme-border\">P<br>r<br>o<br>p<br>o<br>s<br>e</th>"
    ## Incoming responses
    return_string += "<th class=\"sme-border\">1XX</th>"
    return_string += "<th class=\"sme-border\">2XX</th>"
    return_string += "<th class=\"sme-border\">3XX</th>"
    return_string += "<th class=\"sme-border\">4XX</th>"
    return_string += "<th class=\"sme-border\">5XX</th>"
    return_string += "<th class=\"sme-border\">6XX</th>"
    return_string += "<th class=\"sme-border\">Unknown</th>"

    ## Outgoing requests
    ##return_string += "<th class=\"sme-border\">I<br>n<br>v<br>i<br>t<br>e</th>"
    ##return_string += "<th class=\"sme-border\">A<br>c<br>k</th>"
    ##return_string += "<th class=\"sme-border\">O<br>p<br>t<br>i<br>o<br>n<br>s</th>"
    ##return_string += "<th class=\"sme-border\">B<br>y<br>e</th>"
    ##return_string += "<th class=\"sme-border\">C<br>a<br>n<br>c<br>e<br>l</th>"
    return_string += "<th class=\"sme-border\">Register</th>"
    ##return_string += "<th class=\"sme-border\">I<br>n<br>f<br>o</th>"
    ##return_string += "<th class=\"sme-border\">P<br>r<br>a<br>c<br>k</th>"
    ##return_string += "<th class=\"sme-border\">R<br>e<br>f<br>e<br>r</th>"
    return_string += "<th class=\"sme-border\">Subscribe</th>"
    return_string += "<th class=\"sme-border\">Notify</th>"
    ##return_string += "<th class=\"sme-border\">U<br>p<br>d<br>a<br>t<br>e</th>"
    ##return_string += "<th class=\"sme-border\">M<br>e<br>s<br>s<br>a<br>g<br>e</th>"
    ##return_string += "<th class=\"sme-border\">C<br>o<br>m<br>e<br>t</th>"
    ##return_string += "<th class=\"sme-border\">P<br>r<br>o<br>p<br>o<br>s<br>e</th>"

    
    ## Outgoing responses
    return_string += "<th class=\"sme-border\">1XX</th>"
    return_string += "<th class=\"sme-border\">2XX</th>"
    return_string += "<th class=\"sme-border\">3XX</th>"
    return_string += "<th class=\"sme-border\">4XX</th>"
    return_string += "<th class=\"sme-border\">5XX</th>"
    return_string += "<th class=\"sme-border\">6XX</th>"
    return_string += "<th class=\"sme-border\">Unknown</th>"

    ## Error string
    return_string += "<th class=\"sme-border\">TotalErrMsg</th>"
    return_string += "<th class=\"sme-border\">TotalGapped</th>"
    return_string += "<th class=\"sme-border\">TotalTimeout</th>"
    return_string += "<th class=\"sme-border\">TotalSendFail</th></tr>"


    
    if rc == None:
        for line in sip_lines:
            # Time calculations
            line_variables = line.strip().split(',')
            epoch_time = line_variables[1]
            if (int(epoch_time) < int(search_day)) or (int(epoch_time) > search_day_next_day):
                continue
            day = time.localtime(float(line_variables[1])).tm_mday
            month= time.localtime(float(line_variables[1])).tm_mon
            year = time.localtime(float(line_variables[1])).tm_year
            hour = time.localtime(float(line_variables[1])).tm_hour
            min = time.localtime(float(line_variables[1])).tm_min
            sec= time.localtime(float(line_variables[1])).tm_sec
            display_time = "%s/%s/%s:%02d:%02d:%02d" % (str(month) , str(day) , str(year) , int(hour) , int(min) , int(sec))
            return_string += "<tr><td style=\"border-right: 1px solid #cccccc;text-align:right; \">"+display_time+"</td>"

            ## Append relevant data to return_string
            ## Incoming requests
            ##return_string +="<td>"+line_variables[12]+"</td>"
            ##return_string +="<td>"+line_variables[23]+"</td>"
            ##return_string +="<td>"+line_variables[14]+"</td>"
            ##return_string +="<td>"+line_variables[15]+"</td>"
            ##return_string +="<td>"+line_variables[16]+"</td>"
            return_string +="<td style=\"text-align:right;\">"+line_variables[17]+"</td>"
            ##return_string +="<td>"+line_variables[18]+"</td>"
            ##return_string +="<td>"+line_variables[19]+"</td>"
            ##return_string +="<td>"+line_variables[20]+"</td>"
            return_string +="<td style=\"text-align:right;\">"+line_variables[21]+"</td>"
            return_string +="<td style=\"border-right: 1px solid #cccccc;text-align:right; \">"+line_variables[22]+"</td>"
            ##return_string +="<td>"+line_variables[23]+"</td>"
            ##return_string +="<td>"+line_variables[24]+"</td>"
            ##return_string +="<td>"+line_variables[25]+"</td>"
            ##return_string +="<td  style=\"border-right: 1px solid #cccccc \">"+line_variables[26]+"</td>"

            ## Incoming Responses
            return_string +="<td style=\"text-align:right;\">"+line_variables[27]+"</td>"
            return_string +="<td style=\"text-align:right;\">"+line_variables[28]+"</td>"
            return_string +="<td style=\"text-align:right;\">"+line_variables[29]+"</td>"
            return_string +="<td style=\"text-align:right;\">"+line_variables[30]+"</td>"
            return_string +="<td style=\"text-align:right;\">"+line_variables[31]+"</td>"
            return_string +="<td style=\"text-align:right;\">"+line_variables[32]+"</td>"
            return_string +="<td style=\"border-right: 1px solid #cccccc;text-align:right; \">"+line_variables[33]+"</td>"

            ## Outgoing requests
            ##return_string +="<td>"+line_variables[34]+"</td>"
            ##return_string +="<td>"+line_variables[35]+"</td>"
            ##return_string +="<td>"+line_variables[36]+"</td>"
            ##return_string +="<td>"+line_variables[37]+"</td>"
            ##return_string +="<td>"+line_variables[38]+"</td>"
            return_string +="<td style=\"text-align:right;\">"+line_variables[39]+"</td>"
            ##return_string +="<td>"+line_variables[40]+"</td>"
            ##return_string +="<td>"+line_variables[41]+"</td>"
            ##return_string +="<td>"+line_variables[42]+"</td>"
            return_string +="<td style=\"text-align:right;\">"+line_variables[43]+"</td>"
            return_string +="<td style=\"border-right: 1px solid #cccccc;text-align:right; \">"+line_variables[44]+"</td>"
            ##return_string +="<td>"+line_variables[45]+"</td>"
            ##return_string +="<td>"+line_variables[46]+"</td>"
            ##return_string +="<td>"+line_variables[47]+"</td>"
            ##return_string +="<td  style=\"border-right: 1px solid #cccccc \">"+line_variables[48]+"</td>"

            ## Outgoing responses
            return_string +="<td style=\"text-align:right;\">"+line_variables[49]+"</td>"
            return_string +="<td style=\"text-align:right;\">"+line_variables[50]+"</td>"
            return_string +="<td style=\"text-align:right;\">"+line_variables[51]+"</td>"
            return_string +="<td style=\"text-align:right;\">"+line_variables[52]+"</td>"
            return_string +="<td style=\"text-align:right;\">"+line_variables[53]+"</td>"
            return_string +="<td style=\"text-align:right;\">"+line_variables[54]+"</td>"
            return_string +="<td style=\"border-right: 1px solid #cccccc;text-align:right; \">"+line_variables[55]+"</td>"
 
            ## Error strings
            return_string +="<td style=\"text-align:right;\">"+line_variables[8]+"</td>"
            return_string +="<td style=\"text-align:right;\">"+line_variables[9]+"</td>"
            return_string +="<td style=\"text-align:right;\">"+line_variables[10]+"</td>"
            return_string +="<td style=\"border-right: 1px solid #cccccc;text-align:right; \">"+line_variables[11]+"</td>"
 
            return_string +="</tr>"
             


    return_string += "</tbody></table>"
 
    return render(request, 'ucdiag/ajax/modsipinfo.html', {'baseurl': baseurl_ucdiag,
                                                                        'action':'',
                                                                        'bctrail': 'Modules',
                                                                        'modules_sip_info': return_string 
                                                                        })



