#!/usr/bin/python
# coding: utf-8

### UC Client Feedback Logger
### Modified by: Greg Bailey <greg_bailey@mitel.com>
### Date: January 31, 2011


### This script is invoked when the UCA client function "Send Problem
### Report" is invoked by the user.  When that happens, the client submits
### a HTTP POST request with several attached files.  The attached files
### are sent compressed by the client.  This script organizes the attached
### files in a per-incident subdirectory, copies specific server logs, and
### then zips the resulting fileset into a single timestamped ZIP file that
### can be downloaded by the administrator.


import cgi
import email.Utils
import gzip
import os
import shutil
import smtplib
import socket
import sys
import time
import zipfile
import zlib
import traceback
import unicodedata

import mitel.esdblib

import subprocess

def remove_accents(input_str):
    nkfd_form = unicodedata.normalize('NFKD', unicode(input_str,'iso-8859-1'))
    only_ascii = nkfd_form.encode('ASCII', 'ignore')
    return only_ascii

### If DEVELOPMENT_MODE == 1, then also send a notification email to the
### address specified by the DEVELOPMENT_EMAIL value defined below.  The
### subject line is also altered to include the summary as specified by
### the user.

f = open("/var/log/feedback/feedback.log", 'w')
DEVELOPMENT_MODE  = 0

DEVELOPMENT_EMAIL = "uca-support@rndlists.mitel.com"

FEEDBACK_LOG_PATH = "/var/log/feedback"

JETTY_LOG_PATH = "/var/log/jetty"

MICOLLAB_MEETING_LOG_PATH = "/var/lib/tomcat7/webapps/MiCollabMeeting/log/"

UCSERVER_LOG_PATH = "/opt/intertel/log"

UCSERVER_LOGFILES = ("5kCmdEvts.log",
                     "access_log.%s" % (time.strftime('%Y-%m-%d')),
                     "acctpres.evts",
                     "activecalls.evts",
                     "adepm.log",
                     "alarmdc.log",
                     "amcAgent.log",
                     "cim.log",
                     "cstaproxy.diag",
                     "cstaproxy.log",
                     "ctimon.log",
                     "DBChanges.log",
                     "dsm.log",
                     "epm3300.log",
                     "federationgw.log",
                     "imevents.log",
                     "jboss.log",
                     "jsonservice.log",
                     "pbxProxy.log",
                     "popCallLogs_Ex.log",
                     "Proxy5k.log",
                     "proxy.log",
                     "pushnotif.log",
                     "q2kdrv.log",
                     "rps.log",
                     "rtc.log",
                     "see.log",
                     "sipbaccountpresence.log",
                     "sipbpresencemanager.log",
                     "sipims.log",
                     "sipregistrar.log",
                     "svgmgr.log",
                     "SysError.log",
                     "SysInfo.log",
                     "wd.log",
                     "webservice.log",
                     "wspCdrMsg.log",
                     "wspConnDump.log",
                     "wspSipMsg.log",
                     "wsp.log")


fs_dict = cgi.FieldStorage()

### MN00679370 Feedback file from Unknown is generated
if not fs_dict.has_key('files[]'):
    os._exit(0)

user_id = fs_dict.getfirst('application_userid', 'unknown').split('@')[0].replace(os.sep, '_')
user_id_ascii = remove_accents(user_id)

unique_id = "%s-%s" % (time.strftime('%Y%m%d%H%M%S'), user_id_ascii)

os.makedirs("%s/%s" % (FEEDBACK_LOG_PATH, unique_id))

f.write("Creating the feedback directory\n")
### Write out a summary.txt file that contains key/value pairs as
### supplied by the UCA client

f_summary = open("%s/%s/summary.txt" % (FEEDBACK_LOG_PATH, unique_id), "w")

for summary_arg in fs_dict.keys():
    if summary_arg != 'files[]':
        f_summary.write("%s: %s\n" % (summary_arg, fs_dict.getfirst(summary_arg)))

f_summary.close()

f.write("Created the summary log\n")

### Loop through any attached files and make copies to the log directory

if fs_dict.has_key('files[]'):

    if isinstance(fs_dict['files[]'], list):
        ### Most UCA clients send multiple files; we get a list automatically
        file_arg_list = fs_dict['files[]']
    else:
        ### Android only sends one file; construct a list with the single file
        file_arg_list = []
        file_arg_list.append(fs_dict['files[]'])

    for file_arg in file_arg_list:
        sanitized_filename = "%s/%s/%s" % (FEEDBACK_LOG_PATH, unique_id, file_arg.filename.replace(os.sep, '_'))
        file_arg.file.seek(0)
        f_temp = open(sanitized_filename, "w")
        shutil.copyfileobj(file_arg.file, f_temp)
        f_temp.close()
        file_arg.file.close()


### Once the submitted files are copied off, return OK to the client so it doesn't block

if os.fork() != 0:
    print "Content-type: text/plain\n"
    sys.exit(0)


### Create the ZIP file that will hold the collection of log files

zf = zipfile.ZipFile("%s/%s.zip" % (FEEDBACK_LOG_PATH, unique_id), "w", zipfile.ZIP_DEFLATED)

f.write("Created the ZIP files\n")

### Add copies of server log files to the ZIP file

for server_log in UCSERVER_LOGFILES:

    ### Add the file as is to the ZIP file
    zip_member_src = "%s/%s" % (UCSERVER_LOG_PATH, server_log)
    zip_member_name = "%s/server/%s" % (unique_id, server_log)
    try:
        zf.write(zip_member_src, zip_member_name)
    except:
        pass

f.write("Added the server logs\n")
### copy additional wsp log files
try:
    log_files = os.listdir(UCSERVER_LOG_PATH)
    wsp_log_files = []
    for log_name in log_files: 
        if log_name.startswith("wsp."):
            if log_name == "wsp.log":
                continue
            wsp_log_files.append(log_name)

    for server_log in wsp_log_files:
        zip_member_src = "%s/%s" % (UCSERVER_LOG_PATH, server_log)
        zip_member_name = "%s/server/%s" % (unique_id,server_log)
        zf.write(zip_member_src, zip_member_name)
except:
    f.write(traceback.format_exc())
    pass

f.write("Added the WSP logs\n")
### Add the files submitted by the client to the ZIP file
for client_log in os.listdir("%s/%s" % (FEEDBACK_LOG_PATH, unique_id)):

    zip_member_src = "%s/%s/%s" % (FEEDBACK_LOG_PATH, unique_id, client_log)
    try:
        if client_log.endswith('.gz'):
            ### Uncompress the log file because it will be recompressed by ZIP
            zip_member_name = "%s/client/%s" % (unique_id, client_log[:-3])
            zf.writestr(zip_member_name, gzip.GzipFile(zip_member_src, "r").read())
        else:
            ### Add the file as is to the ZIP file
            zip_member_name = "%s/client/%s" % (unique_id, client_log)
            zf.write(zip_member_src, zip_member_name)
    except:
        f.write(traceback.format_exc())
        pass

f.write("Added the client logs\n")
### Add jetty log file to the ZIP file

try:
    zip_member_src = "%s/current" % (JETTY_LOG_PATH)
    zip_member_name = "%s/server/jetty.log" % (unique_id)
    zf.write(zip_member_src, zip_member_name)
except:
    f.write(traceback.format_exc())
    pass

f.write("Added the Jetty logs\n")
### Copy webrtc log in tmp file

try:
    mbg_version = os.popen("rpm -qa | grep Blade-MiVoice_Border_Gateway | awk -F '-' '{print $3}'| awk -F '.' '{print $1\".\"$2}'").read()
    if mbg_version != "": 
        if float(mbg_version.strip()) >= 9.4:
            webrtc_log_file = "/var/log/webrtc/webrtc.log"
        else:
            webrtc_log_file = "/var/log/webrtc/current"
    
        tmp_webrtc_log_file = "%s/%s/webrtc.log" % (FEEDBACK_LOG_PATH, unique_id)
        try:
            subprocess.run("/opt/intertel/bin/collectWebRtcLog %s %s" % (webrtc_log_file, tmp_webrtc_log_file), check=True)
        except:
            f.write(traceback.format_exc())
            pass
    
    ### Add webrtc log file to the ZIP file
    
    zip_member_src = "%s" % (tmp_webrtc_log_file)
    zip_member_name = "%s/server/webrtc.log" % (unique_id)
    zf.write(zip_member_src, zip_member_name)
except:
    f.write(traceback.format_exc())
    pass

f.write("Added the MBG logs\n")

### Add micollabmeeting.log file to the ZIP file

try:
    zip_member_src = "%s/micollabmeeting.log" % (MICOLLAB_MEETING_LOG_PATH)
    zip_member_name = "%s/server/micollabmeeting.log" % (unique_id)
    zf.write(zip_member_src, zip_member_name)
except:
    f.write(traceback.format_exc())
    pass

f.write("Added MiCollab meeting logs\n")
### Close the ZIP file and clean up the temporary working directory

zf.close()

shutil.rmtree("%s/%s" % (FEEDBACK_LOG_PATH, unique_id), 1)

f.write("Deleting the temp directory\n")

f.close()
### Send a notification e-mail to the administrative contact if one is defined

db_accounts = mitel.esdblib.EsmithDb('accounts')
db_configuration = mitel.esdblib.EsmithDb('configuration')

fqdn = db_configuration.getRecord('SystemName').type \
           + "." \
           + db_configuration.getRecord('DomainName').type

from_address = "uca.no.reply@%s" % fqdn
to_address = db_accounts.getRecord('admin').getPropValue('ForwardAddress')

if to_address not in (None, ''):
    msg = ""

    msg += "Date: %s\r\n" % email.Utils.formatdate(localtime = True)
    msg += "From: Mitel Unified Communicator Advanced <%s>\r\n" % from_address

    if DEVELOPMENT_MODE == 1:
        msg += "To: %s, %s\r\n" % (DEVELOPMENT_EMAIL, to_address)
        if fs_dict.has_key('error_briefdescription'):
            msg += "Subject: UCA problem (%s@%s): %s\r\n" % (user_id, socket.gethostname().split('.')[0], fs_dict.getfirst('error_briefdescription'))
        else:
            msg += "Subject: UCA problem (%s@%s)\r\n" % (user_id, socket.gethostname().split('.')[0])

    else:
        msg += "To: %s\r\n" % to_address
        msg += "Subject: =?UTF-8?Q?Mitel=C2=AE_Unified_Communicator_Advanced_Problem_Report_Submission?=\r\n"

    msg += "\r\n"

    msg += "A Mitel Unified Communicator Advanced user has submitted a problem report.\r\n"
    msg += "\r\n"

    if fs_dict.has_key('application_userid'):
        msg += "User ID:  %s\r\n" % fs_dict.getfirst('application_userid')
        msg += "\r\n"

    if fs_dict.has_key('application_productname') and fs_dict.has_key('application_productid'):
        msg += "Product:  %s %s\r\n" % (fs_dict.getfirst('application_productname'), fs_dict.getfirst('application_productid'))

    if fs_dict.has_key('application_productversion'):
        msg += "Version:  %s\r\n" % fs_dict.getfirst('application_productversion')
        msg += "\r\n"

    if fs_dict.has_key('error_briefdescription'):
        msg += "Summary:  %s\r\n" % fs_dict.getfirst('error_briefdescription')
        msg += "\r\n"

    if fs_dict.has_key('error_userdescription'):
        msg += "Description:\r\n"
        msg += fs_dict.getfirst('error_userdescription')
        msg += "\r\n"
        msg += "\r\n"

    if fs_dict.has_key('files[]'):
        msg += "Files included in problem report %s.zip:\r\n\r\n" % unique_id

        if isinstance(fs_dict['files[]'], list):
            for file_arg in fs_dict['files[]']:
                sanitized_filename = "%s/client/%s" % (unique_id, file_arg.filename.replace(os.sep, '_'))
                if sanitized_filename.endswith('.gz'):
                    msg += "%s\r\n" % sanitized_filename[:-3]
                else:
                    msg += "%s\r\n" % sanitized_filename
        else:
            sanitized_filename = "%s/client/%s" % (unique_id, fs_dict['files[]'].filename.replace(os.sep, '_'))
            if sanitized_filename.endswith('.gz'):
                msg += "%s\r\n" % sanitized_filename[:-3]
            else:
                msg += "%s\r\n" % sanitized_filename
        msg += "\r\n"

        for file_arg in UCSERVER_LOGFILES:
            msg += "%s/server/%s\r\n" % (unique_id, file_arg)
        msg += "\r\n"

        msg += "The zip file named \"feedback/%s.zip\"\r\n" % unique_id
        msg += "containing the above files may be downloaded using the\r\n"
        msg += "\"View log files\" functionality provided by Server Manager.\r\n"
        msg += "\r\n"

    msg += "Click the following link to access Server Manager:\r\n"
    msg += "https://%s/server-manager/\r\n" % fqdn
    msg += "\r\n"

    msg += "---------------------------------------------------------------------------\r\n"
    msg += "This notification is an automatically generated e-mail message.\r\n"
    msg += "Do not reply to this message.\r\n"

    server = smtplib.SMTP('localhost')

    if DEVELOPMENT_MODE == 1:
        server.sendmail(from_address, (DEVELOPMENT_EMAIL, to_address), msg)
    else:
        server.sendmail(from_address, to_address, msg)

    server.quit()


### Don't return to Apache -- this is the child process

os._exit(0)



